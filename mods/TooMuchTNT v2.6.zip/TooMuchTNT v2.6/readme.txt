TooMuchTNT v2.6

for minecraft 1.6.4


Requires:
-Minecraft Forge

Installing:
	Windows;
First to install forge all you need to do is open what you have downloaded and ok, it will automatically install forge for you. If your download of "TooMuchTNT v2.6" is zipped, unzip it. Then go to "Start" and type in search bar %appdata%, click the folder then find ".minecraft" and open the "mods" folder. There is where you will drag the the "TooMuchTNT v2.6" into.

	Macintosh;
First to install forge all you need to do is open what you have downloaded and ok, it will automatically install forge for you. If your download of "TooMuchTNT v2.6" is zipped, unzip it. Then go to Finder and go to your name (usually starts you there)
and click "Library" , "ApplicationSupport" , "Minecraft", then "mods". There is where you will drag the the "TooMuchTNT v2.6" into. If there isn't a folder named "mods" already, create one.

TooMuchTNT config:
You can change ID's and others things in the TooMuchTNT.cfg which is located in ".minecraft/config". In the config you can also edit many options for CustomTNT.

Credits:
Minecraft Forum Name: MinecraftTNTstuff
Minecraft Account Name: aquasquid36

Do not post my mod on other sites please, owner: MinecraftTNTstuff